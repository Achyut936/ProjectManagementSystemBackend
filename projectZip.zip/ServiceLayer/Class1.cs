﻿namespace ServiceLayer
{
    public class Class1
    {

    }
}