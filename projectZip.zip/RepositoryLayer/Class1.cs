﻿namespace RepositoryLayer
{
    public class Class1
    {

    }
}